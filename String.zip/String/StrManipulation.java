import java.util.*;
class StrManipulation
{
	public static void main(String[] args)
	{
		//String Using New Operator
		char chs[]={'A','N','U'};
		String newStr=new String(chs);
		System.out.println("New string using new operator:"+newStr);
		//String Length
		System.out.println("\b");
		System.out.println("-----STRING LENGTH-----");
		String s1="Hello";
		String s2="World";
		System.out.println("String length of " +s1+ ":" +s1.length());
		//To Uppercase & Lowercase
		System.out.println("\b");
		System.out.println("-----UPPERCASE & LOWERCASE-----");
		System.out.println(s1+"to uppercase:"+s1.toUpperCase());
		System.out.println(s1+"to lowercase:"+s1.toLowerCase());
		//String Concatenation
		System.out.println("\b");
		System.out.println("-----STRING CONCATENATION-----");
		System.out.println("Using Concat(): "+s1.concat(s2));
		System.out.println("Using + Operator : "+s1 + s2);
		//Character Extraction
		System.out.println("\b");
		System.out.println("-----CHARACTER EXTRACTION-----");
		System.out.println("Character at 2nd position:"+s1.charAt(2));
		char c[]=new char[5];
		s2.getChars(1,4,c,0);
		System.out.println("Character between 1 and 4:"+new String(c));
		s1="World";
		s2="hello";
		//Character Comparison
		System.out.println("\b");
		System.out.println("-----CHARACTER COMPARISON-----");
		System.out.println(s1+ " Equals "+s2+ " : " +s1.equals(s2));
		System.out.println(s1+" Equals ignore case " +s2+" : "+s1.equalsIgnoreCase(s2));
		System.out.println(s1+ " Start with W:"+s1.startsWith("W"));
		System.out.println(s1+" End with d:"+":"+s1.endsWith("d"));
		//Search Substring
		System.out.println("\b");
		System.out.println("-----SEARCH SUBSTRING-----");
		s1="have a nice day";
		System.out.println("Index of nice in : "+s1+" is "+s1.indexOf("nice"));
		//Modify String
		System.out.println("\b");
		System.out.println("-----MODIFY STRING-----");
		System.out.println("Substring of "+s1+" : "+s1.substring(12));
		System.out.println("String replacing : "+s1.replace("nice","good"));
		//Using valueOf()
		System.out.println("\b");
		System.out.println("-----USING valueOf()-----");
		float n=15.3f;
		System.out.println(n+" is converted to : "+String.valueOf(n));
	}
}
