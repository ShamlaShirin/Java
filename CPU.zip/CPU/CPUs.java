class CPU
{
	int price=48000;
	class Processor
	{
		int noOfCores=4;
		String manufacturer="Intel Corp";
		void display()
		{
			System.out.println("\nProcessor");
			System.out.println("----------");
			System.out.println("Number of Cores= "+noOfCores);
			System.out.println("Manufacturer= "+manufacturer);
		}
	}
	void display()
	{
		Processor p=new Processor();
		p.display();
		System.out.println("\nCPU");
		System.out.println("----");
		System.out.println("Price= "+price);
	}
	static class RAM
	{
		int memory=1;   
		String manufacturer="Corsair";
		void display()
		{
			System.out.println("\nRAM");
			System.out.println("----");
			System.out.println("Memory= "+memory);
			System.out.println("Manufacturer= "+manufacturer);
			System.out.println("\n");
		}
	}
}
class CPUs
{
	public static void main(String[] args)
	{
		CPU c=new CPU();
		c.display();
		CPU.RAM r=new CPU.RAM();
		r.display();
	}
}





