import java.util.*;
class ArraySearch
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of elements:");
		int size=sc.nextInt();
		int num[]=new int[size];
		System.out.println("Enter the elements:");
		for(int i=0;i<size;i++)
		{
			num[i]=sc.nextInt();
		}
		ArraySearch as=new ArraySearch();
		System.out.println("Enter the Element to Search :");
		int se=sc.nextInt();
		System.out.println("Choose search option...");
		System.out.println("1.Linear Search\n2.Simple Binary Search\n3.Recursive Binary Search\n4.Built-in Search");
		System.out.println("Option:");
		int opt=sc.nextInt();
		int result=-1;
		switch(opt)
		{
			case 1:result=as.linearSearch(se,num);
			break;
			case 2:Arrays.sort(num);
			result=as.simpleBinarySearch(se,num);
			break;
			case 3:Arrays.sort(num);
			result=as.recursiveBinarySearch(num,0,size-1,se);
			break;
			case 4:Arrays.sort(num);
			result=Arrays.binarySearch(num,se);
			break;
			default:
			System.out.println("Invalid Option...");
		}
		if(result>-1)
		{
			System.out.println(se  + " Found:)");
		}
		else
		{
			System.out.println(se + " Not found:(");
		}
	}
	
//Linear search
int linearSearch(int n,int[] numbers)
{
	for(int i=0;i<numbers.length;i++)
	{
		if(numbers[i]==n)
		{
			return 1;
		}	
	}
return -1;
}

//Simple Binary Search
int simpleBinarySearch(int n,int[] num)
{
	int first=0;
	int last=num.length-1;
	int mid=(first+last)/2;
	while(first<=last)
	{
	if(num[mid]<n)
	{
	first=mid+1;
	}
	else if(num[mid]>n)
	{
	last=mid-1;
	}
	else
	{
	return mid;
	}
	mid=(first+last)/2;
	}
	return -1;
}

//Recursive Binary Search
int recursiveBinarySearch(int[] num,int first,int last,int x)
{
	if(first <= last && first <= num.length-1)
	{
		int mid=first + (last-first)/2;
		if(num[mid]<x)
		{
			return recursiveBinarySearch(num,mid+1,last,x);
		}
		if(num[mid]>x)
		{
			return recursiveBinarySearch(num,first,mid-1,x);
		}
		return mid;
	}
	return -1;
}
}


